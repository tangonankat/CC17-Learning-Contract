// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}

val localBuildDir = file("C:/tmp/gradle-builds/LearningContractMobileApp")
layout.buildDirectory.set(localBuildDir.resolve("root"))

subprojects {
    layout.buildDirectory.set(localBuildDir.resolve(name))
}